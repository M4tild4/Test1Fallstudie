
## Packete installieren
install.packages("tidyverse")
library(tidyverse)
install.packages("lubridate")
library(lubridate)
install.packages("tidyr")
library(tidyr)

install.packages("ggplot2")
library(ggplot2)

## Datensatz einbinden
dataframe <- read.csv("202004-divvy-tripdata.csv", header = TRUE, sep = ",")
## Datensatz betrachten
View(dataframe)
## Datensatz detailiert betrachten
str(dataframe)
## Datensatz ohne fehlende Werte erzeugen
data_clean <- na.omit(dataframe) 
## Datensatz ohne fehlende Werte betrachten
View(data_clean)
## Datensatz ohne fehlende Werte detailiert betrachten
str(data_clean)
## Anzahl der Zeilen der beiden Datensätze
nrow(dataframe)
nrow(data_clean)
## Prozentuale Änderung 
(nrow(dataframe)-nrow(data_clean))/nrow(dataframe)*100
## Duplikate löschen 
data1 <- duplicated(data_clean)
nrow(data_clean)
## Erst Datentyp in Date umwandeln und anschließend die Differenz berechnen
data_clean$started_at_clean <- ymd_hms(data_clean$started_at)
data_clean$ended_at_clean <- ymd_hms(data_clean$ended_at)
ride_length <- data_clean$ended_at_clean - data_clean$started_at_clean

## Datensatz mit Widersprüchen löschen Bsp ride_length negativ
data_clean$ride_length <- ride_length

nrow(data_clean)
data_clean <- subset(data_clean, ride_length>0)
nrow(data_clean)


## Mittelwert ermitteln 
data_clean$average_ride_length <- mean(ride_length)
## Stabdardabweichung
sd(ride_length)
mad(ride_length)
max(ride_length)
min(ride_length)
mad(ride_length)

## Streuungsparameter: Streuungsmaße ermitteln
###Varianz
var(ride_length)
###Standardabweichung
sd(ride_length)
###Spannweite
range(ride_length)
###Quartile
quantile(ride_length, c(0.25, 0.75))
###Interquartilbereich
diff(quantile(ride_length, c(0.25, 0.75))) 
###Median Absolute Deviation
mad(ride_length)
###Visualisieren
x <- ride_length
plot(x)
hist(as.numeric(x))


x <- d
y <- countif(member_casual,member)
plot(y)
plot(x)
hist(as.numeric(x))


## neue Variable Wochentag erstellen und analysieren
weekday <- weekdays(data_clean$started_at_clean)
data_clean$weekday <- weekday
####table_weekday <- table(data_clean$weekday, useNA = 'always')
table_weekday <- table(data_clean$weekday)
View(table_weekday)
mean(table_weekday)
sd(table_weekday)
max(table_weekday)
min(table_weekday)

install.packages("dplyr")
install.packages("ggplot2")
library(ggplot2)
library(dplyr)
## neue Variable count_m_c erstellen und analysieren
x<-data_clean %>% 
  count(member_casual, weekday, ride_length, sort=TRUE)

ggplot(x, aes(x=as.factor(weekday), fill=as.factor(weekday))) +
  geom_bar(color="black", fill=rgb(0.1,0.4,0.5,0.7))


tbH<-table(data_clean$member_casual, data_clean$ride_length)
View(tbH)
barplot(tbH)

